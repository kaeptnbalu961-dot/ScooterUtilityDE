# Scooter Utility DE

Android-Prototyp für den Segway Ninebot F3 D / F3 Pro D.

## Enthalten
- Deutsche Jetpack-Compose-Oberfläche
- BLE-Gerätesuche
- Android-12+-Bluetooth-Berechtigungen
- Geräte-/Signal-Anzeige
- Grundlage für eine spätere F3-spezifische GATT-Verbindung

## Noch nicht enthalten
Die proprietären GATT-Services und Befehle des F3 D/Pro D sind bewusst nicht erfunden.
Daher schreibt die App noch keine Scooter-Parameter und ändert keine Firmware- oder Schutzfunktionen.

## Bauen
Projekt in Android Studio öffnen und auf einem Android-Gerät ausführen.

Hinweis: Der Scanner muss noch mit einem UI-State verbunden werden, wenn gefundene Geräte live in der Liste erscheinen sollen. Das Projekt ist deshalb ein sauberer Starter, kein fertiges Utility-Produkt.
