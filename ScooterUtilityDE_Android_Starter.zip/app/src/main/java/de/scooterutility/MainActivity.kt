package de.scooterutility

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.BluetoothLeScanner
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

data class ScooterDevice(val device: BluetoothDevice, val name: String, val rssi: Int)

class MainActivity : ComponentActivity() {
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var scanner: BluetoothLeScanner? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
            if (granted[Manifest.permission.BLUETOOTH_SCAN] == true ||
                granted[Manifest.permission.BLUETOOTH_CONNECT] == true) {
                startScan()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter
        scanner = bluetoothAdapter.bluetoothLeScanner

        setContent {
            ScooterUtilityApp(
                onScan = { ensurePermissionsAndScan() },
                onStop = { stopScan() }
            )
        }
    }

    private fun ensurePermissionsAndScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            ).filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }.toTypedArray()
            if (needed.isNotEmpty()) permissionLauncher.launch(needed) else startScan()
        } else {
            startScan()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        scanner?.startScan(scanCallback)
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        scanner?.stopScan(scanCallback)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName ?: device.name ?: "Unbekanntes Gerät"
            onDeviceFound?.invoke(ScooterDevice(device, name, result.rssi))
        }
    }

    private var onDeviceFound: ((ScooterDevice) -> Unit)? = null

    override fun onResume() {
        super.onResume()
        // Callback wird in der Compose-UI gesetzt; Scan bleibt bewusst manuell.
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScooterUtilityApp(onScan: () -> Unit, onStop: () -> Unit) {
    var scanning by remember { mutableStateOf(false) }
    var devices by remember { mutableStateOf(listOf<ScooterDevice>()) }
    var selected by remember { mutableStateOf<ScooterDevice?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Scooter Utility DE") })
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        "Segway Ninebot F3 D / F3 Pro D",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Deutsche Diagnose- und Utility-App",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scanning = true
                            onScan()
                        }) { Text("Scooter suchen") }

                        OutlinedButton(onClick = {
                            scanning = false
                            onStop()
                        }) { Text("Stop") }
                    }
                }

                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Status", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            Text(if (scanning) "🔎 Suche nach Bluetooth-Geräten …" else "Bereit")
                            Text(
                                "Hinweis: In dieser ersten Version werden Geräte gefunden; die proprietären F3-Befehle werden erst nach einer sicheren BLE-Protokollanalyse implementiert."
                            )
                        }
                    }
                }

                if (selected != null) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Ausgewählter Scooter", style = MaterialTheme.typography.titleLarge)
                                Text(selected!!.name)
                                Text("Signal: ${selected!!.rssi} dBm")
                                Spacer(Modifier.height(8.dp))
                                Text("Verbindung und Datenkanäle folgen in der nächsten Version.")
                            }
                        }
                    }
                }

                item {
                    Text("Gefundene Geräte", style = MaterialTheme.typography.titleLarge)
                }

                items(devices) { d ->
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { selected = d }
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(d.name, style = MaterialTheme.typography.titleMedium)
                            Text("Bluetooth-Adresse: ${d.device.address}")
                            Text("Signal: ${d.rssi} dBm")
                        }
                    }
                }

                item {
                    Text(
                        "Sicherheit: Keine Firmware-, Geschwindigkeits- oder Schutzparameter werden in dieser Version verändert.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
