package de.scooterutility
import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

data class Device(val address:String,val name:String,val rssi:Int)

class MainActivity:ComponentActivity(){
 private lateinit var adapter:BluetoothAdapter
 private var scanner:BluetoothLeScanner?=null
 private val devices=mutableStateListOf<Device>()
 private var scanning by mutableStateOf(false)
 private val perms=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ if(it.values.any{v->v}) scan() }
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  adapter=(getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
  scanner=adapter.bluetoothLeScanner
  setContent { MaterialTheme { Screen(scanning,devices,{requestScan()},{stop()}) } }
 }
 private fun requestScan(){
  if(Build.VERSION.SDK_INT>=31){
   val p=arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT).filter{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED}.toTypedArray()
   if(p.isNotEmpty()) perms.launch(p) else scan()
  } else scan()
 }
 @SuppressLint("MissingPermission") private fun scan(){ if(!adapter.isEnabled)return; devices.clear(); scanning=true; scanner?.startScan(cb) }
 @SuppressLint("MissingPermission") private fun stop(){ scanner?.stopScan(cb); scanning=false }
 private val cb=object:ScanCallback(){
  override fun onScanResult(t:Int,r:ScanResult){ val n=r.scanRecord?.deviceName ?: runCatching{r.device.name}.getOrNull() ?: "Unbekanntes Gerät"; if(devices.none{it.address==r.device.address}) devices.add(Device(r.device.address,n,r.rssi)) }
  override fun onScanFailed(e:Int){scanning=false}
 }
 override fun onDestroy(){stop();super.onDestroy()}
}
@Composable fun Screen(scanning:Boolean,devices:List<Device>,scan:()->Unit,stop:()->Unit){
 Scaffold(topBar={TopAppBar(title={Text("Scooter Utility DE")})}){pad->
  LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   item{Text("Segway Ninebot F3 Pro D",style=MaterialTheme.typography.headlineSmall);Text("Bluetooth-Diagnose")}
   item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(scan){Text("Scooter suchen")};OutlinedButton(stop){Text("Stop")}}}
   item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(if(scanning)"🔎 Suche läuft …" else "Bereit");Text("Gefundene Geräte: ${devices.size}")}}}
   items(devices){d->ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(d.name,style=MaterialTheme.typography.titleMedium);Text(d.address);Text("Signal: ${d.rssi} dBm")}}}
   item{Text("Noch keine proprietären F3-Pro-D-Schreibbefehle oder Firmwareänderungen.",style=MaterialTheme.typography.bodySmall)}
  }
 }
}
